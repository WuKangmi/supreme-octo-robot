with open("api_key.txt", "r") as file:
    api_key = file.read().strip()

import os
os.environ["OPENAI_API_KEY"] = api_key

import time
import openai

# gets API Key from environment variable OPENAI_API_KEY
client = openai.OpenAI()

assistant = client.beta.assistants.create(
    name="Voice Paraphrasing Assistant",
    instructions="You are a Voice Paraphrasing Assistant aiming at supporting the software for speech paraphrasing tools designed for people with non-fluency aphasia. " + 
    "The main function of this paraphrasing tool is to use speech recognition technology and artificial intelligence algorithms (such as ChatGPT) to infer" + 
    " what the patient really wants to say from the patient's possible pauses and slurred voice input and present it in a fluent and grammatically correct manner. " + 
    "In the application, the upper layer will pass a chunk of text message to this model, and this model need to understand and summarize the text content after" + 
    "speech recognition and paraphrase it into fluent, accurate text to better express the user'sintent.",
    model="gpt-3.5-turbo-0125",
)

thread = client.beta.threads.create()

message = client.beta.threads.messages.create(
    thread_id=thread.id,
    role="user",
    content="I did not hear you clearly. Can you repeat that?",
)

run = client.beta.threads.runs.create(
    thread_id=thread.id,
    assistant_id=assistant.id,
    instructions="The user has a premium account.",
)

print("checking assistant status. ")
while True:
    run = client.beta.threads.runs.retrieve(thread_id=thread.id, run_id=run.id)

    if run.status == "completed":
        print("done!")
        messages = client.beta.threads.messages.list(thread_id=thread.id)

        print("messages: ")
        for message in messages:
            assert message.content[0].type == "text"
            print({"role": message.role, "message": message.content[0].text.value})

        client.beta.assistants.delete(assistant.id)

        break
    else:
        print("in progress...")
        time.sleep(5)